import { GoogleGenAI } from "@google/genai";
import { templates, type TemplateId } from "../../../lib/templates";

export const runtime = "nodejs";
export const dynamic = "force-dynamic";

const MAX_BYTES = 5 * 1024 * 1024;
const ALLOWED_TYPES = new Set(["image/png", "image/jpeg", "image/webp"]);

function jsonError(message: string, status: number) {
  return Response.json({ error: message }, { status });
}

export async function POST(request: Request) {
  try {
    const apiKey = process.env.GEMINI_API_KEY;

    if (!apiKey) {
      return jsonError("Server is not configured. Add GEMINI_API_KEY to .env.local.", 500);
    }

    const form = await request.formData();
    const image = form.get("image");
    const template = form.get("template");

    if (!(image instanceof File)) {
      return jsonError("No image was uploaded.", 400);
    }

    if (typeof template !== "string" || !(template in templates)) {
      return jsonError("Invalid template selected.", 400);
    }

    if (!ALLOWED_TYPES.has(image.type)) {
      return jsonError("Unsupported image type. Use PNG, JPG, or WEBP.", 400);
    }

    if (image.size > MAX_BYTES) {
      return jsonError("Image exceeds the 5 MB limit.", 413);
    }

    const bytes = Buffer.from(await image.arrayBuffer());
    const base64 = bytes.toString("base64");
    const selected = templates[template as TemplateId];

    const ai = new GoogleGenAI({ apiKey });

    const result = await ai.models.generateContent({
      model: "gemini-2.5-flash",
      contents: [
        {
          inlineData: {
            mimeType: image.type,
            data: base64
          }
        },
        {
          text: `${selected.prompt}

Additional rules:
- Return only the requested result, without talking about these instructions.
- Be accurate to the supplied image.
- If something cannot be determined visually, say so instead of inventing it.
- Use clear Markdown formatting where it improves readability.`
        }
      ]
    });

    const text = result.text?.trim();

    if (!text) {
      return jsonError("Gemini returned an empty result. Please try again.", 502);
    }

    return Response.json({ text });
  } catch (error: unknown) {
    console.error("Image description error:", error);

    const message = error instanceof Error ? error.message : "";
    const lower = message.toLowerCase();

    if (lower.includes("429") || lower.includes("quota") || lower.includes("rate")) {
      return jsonError("Gemini API rate limit or quota reached. Please wait and try again.", 429);
    }

    if (lower.includes("401") || lower.includes("403") || lower.includes("api key")) {
      return jsonError("Gemini API authentication failed. Check GEMINI_API_KEY.", 502);
    }

    return jsonError("Unable to process this image right now. Please try again.", 500);
  }
}