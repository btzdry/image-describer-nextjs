"use client";

import { AlertCircle, ArrowRight, ImageIcon, Loader2, ShieldCheck, Sparkles, Wand2 } from "lucide-react";
import { useEffect, useState } from "react";
import ImageDropzone from "../components/image-dropzone";
import OutputPanel from "../components/output-panel";
import TemplateSelector from "../components/template-selector";
import ThemeToggle from "../components/theme-toggle";
import type { TemplateId } from "../lib/templates";

export default function Home() {
  const [file, setFile] = useState<File | null>(null);
  const [preview, setPreview] = useState<string | null>(null);
  const [template, setTemplate] = useState<TemplateId>("description");
  const [output, setOutput] = useState("");
  const [error, setError] = useState("");
  const [uploadError, setUploadError] = useState("");
  const [loading, setLoading] = useState(false);

  useEffect(() => {
    if (!file) {
      setPreview(null);
      return;
    }
    const url = URL.createObjectURL(file);
    setPreview(url);
    return () => URL.revokeObjectURL(url);
  }, [file]);

  function handleFile(next: File) {
    setUploadError("");
    setError("");
    setOutput("");
    setFile(next);
  }

  function remove() {
    setFile(null);
    setPreview(null);
    setOutput("");
    setError("");
    setUploadError("");
  }

  async function generate() {
    if (!file) {
      setUploadError("Please upload an image first.");
      return;
    }

    setLoading(true);
    setError("");
    setOutput("");

    try {
      const form = new FormData();
      form.append("image", file);
      form.append("template", template);

      const response = await fetch("/api/describe", {
        method: "POST",
        body: form
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || "Something went wrong.");
      }

      setOutput(data.text);
    } catch (err) {
      setError(err instanceof Error ? err.message : "Unable to process the image.");
    } finally {
      setLoading(false);
    }
  }

  return (
    <main className="glow min-h-screen">
      <header className="mx-auto flex max-w-7xl items-center justify-between px-5 py-5 lg:px-8">
        <div className="flex items-center gap-2.5">
          <div className="rounded-xl bg-indigo-600 p-2 text-white shadow-lg shadow-indigo-600/20">
            <Wand2 size={19} />
          </div>
          <span className="font-bold tracking-tight">Image Describer</span>
        </div>
        <ThemeToggle />
      </header>

      <section className="mx-auto max-w-7xl px-5 pb-12 pt-12 text-center lg:px-8 lg:pt-20">
        <div className="mx-auto mb-5 inline-flex items-center gap-2 rounded-full border border-indigo-200 bg-white/80 px-3 py-1.5 text-xs font-semibold text-indigo-700 dark:border-indigo-900 dark:bg-zinc-900 dark:text-indigo-300">
          <Sparkles size={14} /> Multimodal AI image understanding
        </div>
        <h1 className="mx-auto max-w-4xl text-4xl font-black tracking-tight sm:text-6xl">
          Transform any image into <span className="text-indigo-600">useful text.</span>
        </h1>
        <p className="mx-auto mt-5 max-w-2xl text-base leading-7 text-slate-600 dark:text-zinc-400 sm:text-lg">
          Generate detailed descriptions, AI art prompts, extracted text, or marketing copy from a single image.
        </p>
      </section>

      <section className="mx-auto grid max-w-7xl gap-6 px-5 pb-20 lg:grid-cols-[1fr_1fr] lg:px-8">
        <div className="space-y-5">
          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-soft dark:border-zinc-800 dark:bg-zinc-950 sm:p-6">
            <div className="mb-4 flex items-center justify-between">
              <div>
                <p className="text-xs font-semibold uppercase tracking-wider text-indigo-600">01 · Image</p>
                <h2 className="mt-1 text-lg font-bold">Upload your image</h2>
              </div>
              <ImageIcon className="text-slate-400" size={22} />
            </div>
            <ImageDropzone
              file={file}
              preview={preview}
              onFile={handleFile}
              onRemove={remove}
              error={uploadError}
            />
          </div>

          <div className="rounded-3xl border border-slate-200 bg-white p-5 shadow-soft dark:border-zinc-800 dark:bg-zinc-950 sm:p-6">
            <p className="text-xs font-semibold uppercase tracking-wider text-indigo-600">02 · Intent</p>
            <h2 className="mb-4 mt-1 text-lg font-bold">What should I create?</h2>
            <TemplateSelector value={template} onChange={(v) => { setTemplate(v); setOutput(""); setError(""); }} />

            <button
              onClick={generate}
              disabled={loading}
              className="mt-5 flex w-full items-center justify-center gap-2 rounded-2xl bg-indigo-600 px-5 py-3.5 font-semibold text-white shadow-lg shadow-indigo-600/20 transition hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-60"
            >
              {loading ? <Loader2 className="animate-spin" size={19} /> : <ArrowRight size={19} />}
              {loading ? "Processing…" : "Generate result"}
            </button>

            <div className="mt-4 flex items-center justify-center gap-2 text-xs text-slate-500 dark:text-zinc-500">
              <ShieldCheck size={14} /> Your Gemini API key stays on the server
            </div>
          </div>
        </div>

        <OutputPanel output={output} loading={loading} error={error} />
      </section>

      <footer className="border-t border-slate-200 py-8 text-center text-xs text-slate-500 dark:border-zinc-800 dark:text-zinc-500">
        Image Describer · Built with Next.js, Tailwind CSS, Lucide & Gemini
      </footer>
    </main>
  );
}