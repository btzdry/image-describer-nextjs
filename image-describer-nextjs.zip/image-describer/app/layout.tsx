import type { Metadata } from "next";
import "./globals.css";

export const metadata: Metadata = {
  title: "Image Describer — AI image understanding",
  description: "Turn images into descriptions, AI prompts, OCR text, and marketing copy."
};

export default function RootLayout({ children }: Readonly<{ children: React.ReactNode }>) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body>{children}</body>
    </html>
  );
}