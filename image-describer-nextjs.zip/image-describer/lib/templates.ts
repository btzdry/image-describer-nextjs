export type TemplateId = "description" | "prompt" | "ocr" | "marketing";

export const templates: Record<
  TemplateId,
  { label: string; short: string; prompt: string }
> = {
  description: {
    label: "Detailed Description",
    short: "Break down everything visible",
    prompt: `Create a comprehensive, accurate description of this image. Cover the main subject, people if present, objects, setting, composition, spatial relationships, colors, lighting, mood, textures, clothing, visible actions, and important small details. Do not invent facts that cannot be visually supported. Organize the result with useful headings when appropriate.`
  },
  prompt: {
    label: "AI Image Prompt",
    short: "Create Midjourney / Flux prompts",
    prompt: `Analyze the image and create a high-quality AI image-generation prompt that could recreate its visual appearance. Include subject, composition, camera/lens feel, perspective, lighting, color palette, environment, materials/textures, mood, style, and relevant visual details. Produce a polished main prompt plus a concise negative prompt. Do not identify a real person unless the image clearly contains a public figure and identification is necessary.`
  },
  ocr: {
    label: "Extract Text (OCR)",
    short: "Read all visible text",
    prompt: `Extract all legible text visible in this image. Preserve wording, spelling, capitalization, punctuation, and line/section structure as closely as possible. Do not summarize or rewrite. If some text is uncertain, mark it as [unclear] rather than guessing. If there is no visible text, say: No legible text found.`
  },
  marketing: {
    label: "Marketing Copy",
    short: "Captions, hooks & ad copy",
    prompt: `Use the image to write marketing copy. First infer only the visually supported product, service, event, or subject. Then provide: (1) one strong social caption, (2) three short headline/hook options, (3) one concise ad description, and (4) five relevant hashtags. Keep the copy engaging and avoid unsupported claims.`
  }
};
