"use client";

import { FileImage, Upload, X } from "lucide-react";
import { useRef } from "react";

type Props = {
  file: File | null;
  preview: string | null;
  onFile: (file: File) => void;
  onRemove: () => void;
  error: string;
};

const MAX = 5 * 1024 * 1024;
const TYPES = ["image/png", "image/jpeg", "image/webp"];

export default function ImageDropzone({ file, preview, onFile, onRemove, error }: Props) {
  const inputRef = useRef<HTMLInputElement>(null);

  function validate(next: File) {
    if (!TYPES.includes(next.type)) {
      return "Please choose a PNG, JPG, or WEBP image.";
    }
    if (next.size > MAX) {
      return "Image is too large. Maximum size is 5 MB.";
    }
    return "";
  }

  function select(next: File | undefined) {
    if (!next) return;
    const message = validate(next);
    if (message) {
      onRemove();
      return;
    }
    onFile(next);
  }

  return (
    <div>
      {!file ? (
        <div
          onDragOver={(e) => e.preventDefault()}
          onDrop={(e) => {
            e.preventDefault();
            select(e.dataTransfer.files?.[0]);
          }}
          onClick={() => inputRef.current?.click()}
          className="group cursor-pointer rounded-3xl border-2 border-dashed border-slate-300 bg-white/70 p-10 text-center transition hover:border-indigo-400 hover:bg-indigo-50/40 dark:border-zinc-700 dark:bg-zinc-950/70 dark:hover:border-indigo-500 dark:hover:bg-indigo-950/20"
        >
          <input
            ref={inputRef}
            type="file"
            accept="image/png,image/jpeg,image/webp"
            className="hidden"
            onChange={(e) => select(e.target.files?.[0])}
          />
          <div className="mx-auto mb-5 flex h-14 w-14 items-center justify-center rounded-2xl bg-indigo-100 text-indigo-600 dark:bg-indigo-950 dark:text-indigo-300">
            <Upload size={25} />
          </div>
          <h3 className="text-lg font-semibold">Drop your image here</h3>
          <p className="mt-2 text-sm text-slate-500 dark:text-zinc-400">
            or click to browse · PNG, JPG, WEBP · max 5 MB
          </p>
        </div>
      ) : (
        <div className="relative overflow-hidden rounded-3xl border border-slate-200 bg-white dark:border-zinc-800 dark:bg-zinc-950">
          {preview && (
            <img
              src={preview}
              alt="Selected image preview"
              className="max-h-[420px] w-full object-contain bg-slate-100 dark:bg-zinc-900"
            />
          )}
          <div className="flex items-center justify-between gap-4 p-4">
            <div className="flex min-w-0 items-center gap-3">
              <FileImage size={20} className="shrink-0 text-indigo-500" />
              <div className="min-w-0">
                <p className="truncate text-sm font-medium">{file.name}</p>
                <p className="text-xs text-slate-500">{(file.size / 1024 / 1024).toFixed(2)} MB</p>
              </div>
            </div>
            <button
              onClick={onRemove}
              className="rounded-xl border border-slate-200 p-2 text-slate-600 hover:bg-slate-100 dark:border-zinc-700 dark:text-zinc-300 dark:hover:bg-zinc-800"
              aria-label="Remove image"
            >
              <X size={18} />
            </button>
          </div>
        </div>
      )}
      {error && <p className="mt-2 text-sm font-medium text-red-500">{error}</p>}
    </div>
  );
}