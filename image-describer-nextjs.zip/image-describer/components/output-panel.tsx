import { Check, Clipboard, Download, FileOutput, Loader2 } from "lucide-react";
import { useState } from "react";

export default function OutputPanel({
  output,
  loading,
  error
}: {
  output: string;
  loading: boolean;
  error: string;
}) {
  const [copied, setCopied] = useState(false);

  async function copy() {
    if (!output) return;
    await navigator.clipboard.writeText(output);
    setCopied(true);
    setTimeout(() => setCopied(false), 1600);
  }

  function download() {
    if (!output) return;
    const blob = new Blob([output], { type: "text/plain;charset=utf-8" });
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "image-description.txt";
    a.click();
    URL.revokeObjectURL(url);
  }

  return (
    <section className="rounded-3xl border border-slate-200 bg-white shadow-soft dark:border-zinc-800 dark:bg-zinc-950">
      <div className="flex items-center justify-between border-b border-slate-200 p-5 dark:border-zinc-800">
        <div className="flex items-center gap-3">
          <div className="rounded-xl bg-slate-100 p-2 dark:bg-zinc-900">
            <FileOutput size={18} />
          </div>
          <div>
            <h2 className="font-semibold">Generated result</h2>
            <p className="text-xs text-slate-500 dark:text-zinc-400">Your AI-powered output</p>
          </div>
        </div>
        {output && !loading && (
          <div className="flex gap-2">
            <button onClick={copy} className="inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-sm hover:bg-slate-50 dark:border-zinc-700 dark:hover:bg-zinc-900">
              {copied ? <Check size={16} /> : <Clipboard size={16} />}
              {copied ? "Copied" : "Copy"}
            </button>
            <button onClick={download} className="inline-flex items-center gap-2 rounded-xl border px-3 py-2 text-sm hover:bg-slate-50 dark:border-zinc-700 dark:hover:bg-zinc-900">
              <Download size={16} /> TXT
            </button>
          </div>
        )}
      </div>

      <div className="min-h-[360px] p-6">
        {loading ? (
          <div className="space-y-4 animate-pulse">
            <div className="h-4 w-1/3 rounded bg-slate-200 dark:bg-zinc-800" />
            <div className="h-4 w-full rounded bg-slate-200 dark:bg-zinc-800" />
            <div className="h-4 w-11/12 rounded bg-slate-200 dark:bg-zinc-800" />
            <div className="h-4 w-4/5 rounded bg-slate-200 dark:bg-zinc-800" />
            <div className="mt-8 h-4 w-1/2 rounded bg-slate-200 dark:bg-zinc-800" />
            <div className="h-24 rounded-2xl bg-slate-100 dark:bg-zinc-900" />
            <div className="flex items-center gap-2 pt-4 text-sm text-slate-500">
              <Loader2 className="animate-spin" size={16} /> Analyzing your image…
            </div>
          </div>
        ) : error ? (
          <div className="rounded-2xl border border-red-200 bg-red-50 p-5 text-sm text-red-700 dark:border-red-950 dark:bg-red-950/20 dark:text-red-300">
            {error}
          </div>
        ) : output ? (
          <div className="output-prose text-[15px] text-slate-700 dark:text-zinc-200">{output}</div>
        ) : (
          <div className="flex min-h-[300px] flex-col items-center justify-center text-center">
            <div className="mb-4 rounded-2xl bg-slate-100 p-4 dark:bg-zinc-900">
              <FileOutput size={25} className="text-slate-500" />
            </div>
            <p className="font-medium">Your result will appear here</p>
            <p className="mt-1 max-w-sm text-sm text-slate-500 dark:text-zinc-400">
              Upload an image, choose a template, then generate your result.
            </p>
          </div>
        )}
      </div>
    </section>
  );
}