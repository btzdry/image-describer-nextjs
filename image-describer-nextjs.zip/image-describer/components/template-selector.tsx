import { FileText, ImageIcon, ScanText, Sparkles } from "lucide-react";
import type { TemplateId } from "../lib/templates";
import { templates } from "../lib/templates";

const icons = {
  description: FileText,
  prompt: Sparkles,
  ocr: ScanText,
  marketing: ImageIcon
};

export default function TemplateSelector({
  value,
  onChange
}: {
  value: TemplateId;
  onChange: (value: TemplateId) => void;
}) {
  return (
    <div className="grid gap-2 sm:grid-cols-2">
      {(Object.keys(templates) as TemplateId[]).map((id) => {
        const Icon = icons[id];
        const active = value === id;
        return (
          <button
            key={id}
            onClick={() => onChange(id)}
            className={`flex items-center gap-3 rounded-2xl border p-4 text-left transition ${
              active
                ? "border-indigo-500 bg-indigo-50 text-indigo-950 shadow-sm dark:border-indigo-500 dark:bg-indigo-950/40 dark:text-white"
                : "border-slate-200 bg-white hover:border-indigo-300 dark:border-zinc-800 dark:bg-zinc-950 dark:hover:border-zinc-600"
            }`}
          >
            <span className={`rounded-xl p-2.5 ${active ? "bg-indigo-600 text-white" : "bg-slate-100 dark:bg-zinc-900"}`}>
              <Icon size={18} />
            </span>
            <span>
              <span className="block text-sm font-semibold">{templates[id].label}</span>
              <span className="mt-0.5 block text-xs text-slate-500 dark:text-zinc-400">{templates[id].short}</span>
            </span>
          </button>
        );
      })}
    </div>
  );
}